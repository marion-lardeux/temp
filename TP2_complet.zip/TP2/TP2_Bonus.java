import java.io.IOException;
import java.math.BigDecimal;
import java.util.Random;

public class TP2_Bonus{
	public static CpxImg noise_synthesis(int n, double alpha){
		CpxImg FI = new CpxImg(n);
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				double mod = Math.random() * alpha;
				double phase = Math.random() * alpha;
				FI.set_p_reel(i, j, mod * Math.cos(phase));
				FI.set_p_imag(i, j, mod * Math.sin(phase));
			}
		}
		CpxImg I = FFT_2D.FFT_inverse(FI);
		double max=0, min=0;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				double reel = I.get_p_reel(i, j);
				max = reel>max ? reel : max;
				min = reel<min ? reel : min;
			}
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				I.set_p_reel(i, j, 255*(I.get_p_reel(i, j)-min)/(max-min));
				I.set_p_imag(i, j, 0);
			}
		}
		return I;
	}
	public static CpxImg texture_synthesis(int n, double alpha){
		CpxImg FI = new CpxImg(n);
		int n_2 = n/2;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				int k = i - n_2;
				int l = j - n_2;
				double r = Math.sqrt(k * k + l * l);
				double mod = Math.pow(1 + r, -alpha);
				double phase = Math.random()*2 * Math.PI;
				FI.set_p_reel(i, j, mod * Math.cos(phase));
				FI.set_p_imag(i, j, mod * Math.sin(phase));
			}
		}
		CpxImg I = FFT_2D.FFT_inverse(FI);
		double max=0, min=0;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				double reel = I.get_p_reel(i, j);
				max = reel>max ? reel : max;
				min = reel<min ? reel : min;
			}
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				I.set_p_reel(i, j, 255*(I.get_p_reel(i, j)-min)/(max-min));
				I.set_p_imag(i, j, 0);
			}
		}
		return I;
	}
	
	public static CpxImg phase_randomization(CpxImg I){
		int n = I.taille();
		CpxImg FI = FFT_2D.FFT(I);
		
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				double phase;
				if((n - i)%n == i && (n- j)%n == j){
					phase = 0;
					FI.set_p_imag(i, j, 0);
				} else if(i * n + j < (n - i)%n * n + (n- j)%n){
					phase = Math.random() * 2. * Math.PI;
					double reel = FI.get_p_reel(i, j);
					double imag = FI.get_p_imag(i, j);
					double mod = Math.sqrt(reel * reel + imag * imag);
					FI.set_p_reel(i, j, mod * Math.cos(phase));
					FI.set_p_imag(i, j, mod * Math.sin(phase));
					double reel_ant = FI.get_p_reel((n-i) % n, (n-j)%n);
					double imag_ant = FI.get_p_imag((n-i) % n, (n-j)%n);
					double mod_ant = Math.sqrt(reel_ant * reel_ant + imag_ant * imag_ant);
					FI.set_p_reel((n-i) % n, (n-j)%n, mod_ant * Math.cos(phase));
					FI.set_p_imag((n-i) % n, (n-j)%n, mod_ant * Math.sin(-phase));
				}
			}
		}
		CpxImg New_I = FFT_2D.FFT_inverse(FI);
		double max=0, min=0;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				double reel = New_I.get_p_reel(i, j);
				max = reel>max ? reel : max;
				min = reel<min ? reel : min;
			}
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				New_I.set_p_reel(i, j, 255*(New_I.get_p_reel(i, j)-min)/(max-min));
				New_I.set_p_imag(i, j, 0);
			}
		}
		return New_I;
	}
	public static void main(String[] args) {
		CpxImg i = noise_synthesis(512, 1000);
		i.convert_to_BytePixmap().write("bruit.pgm");
		double[] alphas = {0.5, 1, 2, 3, 4, 5};
		for(double alpha : alphas){
			i = texture_synthesis(512, alpha);
			i.convert_to_BytePixmap().write("simplex_%s.pgm".formatted(BigDecimal.valueOf(alpha).stripTrailingZeros().toPlainString()));
		}
		try{
			for(int k = 1; k <= 4; k++){
				BytePixmap p = new BytePixmap("texture%d.pgm".formatted(k));
				i = new CpxImg(p);
				phase_randomization(i).convert_to_BytePixmap().write("texture%d_random.pgm".formatted(k));
			}
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
}