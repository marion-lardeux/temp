import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.awt.Window;

import javax.swing.SwingUtilities;

/**** on va ici implémenter la transformée de Fourier rapide 1D ****/

public class FFT_1D {
	
	//"combine" c1 et c2 selon la formule vue en TD
	// c1 et c2 sont de même taille
	// la taille du résultat est le double de la taille de c1
	public static CpxTab combine(CpxTab c1, CpxTab c2) {
		assert (c1.taille()==c2.taille()) : "combine: c1 et c2 ne sont pas de même taille, taille c1="+c1.taille()+" taille c2="+c2.taille();
		int n_2 = c1.taille();
		int n = n_2 * 2;
		CpxTab c3 = new CpxTab(n);
		for(int k = 0; k < n_2; k++){
			// omega_n^k calcule directement (pas par multiplications successives : l'erreur s'accumule)
			double w_r_k = Math.cos(2 * Math.PI * k / n);
			double w_i_k = Math.sin(2 * Math.PI * k / n);
			double t_r = w_r_k * c2.get_p_reel(k) - w_i_k * c2.get_p_imag(k);
			double t_i = w_r_k * c2.get_p_imag(k) + w_i_k * c2.get_p_reel(k);
			c3.set_p_reel(k, c1.get_p_reel(k) + t_r);
			c3.set_p_imag(k, c1.get_p_imag(k) + t_i);
			c3.set_p_reel(k + n_2, c1.get_p_reel(k) - t_r);
			c3.set_p_imag(k + n_2, c1.get_p_imag(k) - t_i);
		}
		return c3;
	}

	//renvoie la TFD d'un tableau de complexes
	//la taille de x doit être une puissance de 2
	public static CpxTab FFT(CpxTab x) {
		//A FAIRE : Test d'arrêt
		if(x.taille() == 1){
			return x;
		}

		assert (x.taille()%2==0) : "FFT: la taille de x doit être une puissance de 2";
		
		//A FAIRE : Décomposition en "pair" et "impair" et appel récursif
		int n_2 = x.taille()/2;
		CpxTab x_pair = new CpxTab(n_2);
		CpxTab x_impair = new CpxTab(n_2);
		for(int k = 0; k < n_2; k++){
			x_pair.set_p_reel(k, x.get_p_reel(k*2));
			x_pair.set_p_imag(k, x.get_p_imag(k*2));
			x_impair.set_p_reel(k, x.get_p_reel(k*2 + 1));
			x_impair.set_p_imag(k, x.get_p_imag(k*2 + 1));
		}

		return combine(FFT(x_pair), FFT(x_impair));
	}

	//renvoie la TFD d'un tableau de réels
	//la taille de x doit être une puissance de 2
	public static CpxTab FFT(double[] x) {
		return FFT(new CpxTab(x));
	}
			
	//renvoie la transformée de Fourier inverse de y
	public static CpxTab FFT_inverse(CpxTab y) {
		//A FAIRE
		CpxTab y_inv = FFT(y.conjugue()).conjugue();
		int n = y.taille();
		for(int i = 0; i < n; i++){
			y_inv.set_p_reel(i, y_inv.get_p_reel(i)/n);
			y_inv.set_p_imag(i, y_inv.get_p_imag(i)/n);
		}
		return y_inv;
	}
	
	//calcule le produit de deux polynômes en utilisant la FFT
	//tab1 et tab2, sont les coefficients de ces polynômes
	// CpxTab sera le tableau des coefficients du polynôme produit (purement réel)
	public static CpxTab multiplication_polynome_viaFFT(double[] tab1, double[] tab2) {
		
		//on commence par doubler la taille des vecteurs en rajoutant des zéros à la fin (cf TD)
		double[] t1 = new double[2*tab1.length], t2 = new double[2*tab1.length];
		for (int i = 0; i < tab1.length; i++) {
			t1[i] = tab1[i];
			t2[i] = tab2[i];
		}

		//A COMPLETER !!
		return FFT_inverse(CpxTab.multiplie(FFT(new CpxTab(t1)), FFT(new CpxTab(t2))));
	}

	
	//renvoie un tableau de réels aléatoires
	//utile pour tester la multiplication de polynômes
	public static double[] random(int n) {
		double[] t = new double[n];

		for (int i = 0; i < n; i++)
			t[i] = Math.random();
		return t;
	}

	//effectue la multiplication de polynômes représentés par coefficients
	// p1, p2 les coefficients des deux polynômes P1 et P2
	// renvoie les coefficients du polynôme P1*P2
	private static double [] multiplication_polynome_viaCoeff(double[] p1, double[] p2){
		
		int n = p1.length + p2.length - 1;
		double a,b;
		double [] out = new double[n];
		for (int k = 0; k < n; k++) {
			for (int i = 0; i <= k; i++) {
				a = (i<p1.length) ? p1[i]:0;
				b = (k-i<p2.length) ? p2[k-i] : 0;
				out[k] += a*b;
			}
		}
		return out;
	}
	

	//affiche un tableau de réels
	private static void afficher(double [] t){
		System.out.print("[");
		for(int k=0;k<t.length;k++){
			System.out.print(t[k]);
			if (k<(t.length-1))
				System.out.print(" ");
		}
		System.out.println("]");
	}

	private static final String[] units = { "secondes", "minutes", "heures", "jours", "années" };
	private static final double[] unitsConvert = { 1000, 60, 60, 24, 365.2425 };

	static double regression(List<Integer> N, List<Integer> f_N, Function<Integer, Double> f){
		return (double) IntStream.range(0, N.size()).mapToDouble(i -> (double) f.apply(N.get(i)) * f_N.get(i)).sum() / (double) N.stream().mapToDouble(n -> (double) Math.pow(f.apply(n), 2)).sum();
	}

	public static double tempsCalcul(Function<Integer, Double> f, int n, double a){
		return a * f.apply(n);
	}

	public static String tempsCalculFormat(Function<Integer, Double> f, int n, double a){
		double tempsCalc = tempsCalcul(f, n, a) / unitsConvert[0];
		List<Long> res = new ArrayList<>();
		int i = 1;
		while(tempsCalc > Long.MAX_VALUE){
			tempsCalc /= unitsConvert[i];
			i++;
		}
		final int l = i;
		res.add((long)tempsCalc);
		while(i < unitsConvert.length){
			long temps = (long)(res.getLast()/unitsConvert[i]);
			if(temps == 0){
				break;
			}
			res.set(res.size()-1, (long)(res.getLast() - temps * unitsConvert[i]));
			res.add(temps);
			i++;
		}
		return IntStream.range(0, res.size()).mapToObj(k -> "%d %s".formatted(res.get(res.size()-k-1), units[res.size()-k-1+l-1])).collect(Collectors.joining(", "));
	}
	final static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		double[] t5 = {1,2,3,4};

		/* Exo 2: calculez et affichez TFD(1,2,3,4) */
		System.out.println(FFT(new CpxTab(t5)));
		
		/* Exo 3: calculez et affichez TFD_inverse(TFD(1,2,3,4)) */
		System.out.println(FFT_inverse(FFT(new CpxTab(t5))));		

		/* Exo 4: multiplication polynomiale, vérification*/
			/* A(X) = 2 et B(X)=-3 */
			//A FAIRE	
		double[] A1 = {2};
		double[] B1 = {-3};
		System.out.println(multiplication_polynome_viaFFT(A1, B1));

			/* A(X) = 2+X et B(X)= -3+2X */
			//A FAIRE					
		double[] A2 = {2, 1};
		double[] B2 = {-3, 2};
		System.out.println(multiplication_polynome_viaFFT(A2, B2));

			/* A(X) = 1 + 2X + 3X^2 + 4X^3 et B(X) = -3 + 2X - 5 X^2*/
		System.out.println("-----------------------------------------------------");
		System.out.println("   Comparaison des 2 méthodes de multiplications polynomiales");
		double[] t6 = {-3,2,-5,0};
		System.out.println("mult via FFT  --> " + multiplication_polynome_viaFFT(t5, t6));
		System.out.print(  "mult via coeff -> ");
		afficher(multiplication_polynome_viaCoeff(t5, t6));

		/* Exo 5: comparaison des temps de calculs */
		// Pour étude du temps de calcul 
		int taille = 2048;  // taille des polynômes à multiplier (testez différentes valeurs en gardant des puissances de 2)
			
		System.out.println("Temps de calcul pour n="+taille);
		double[] tab1 =random(taille),tab2 = random(taille);
		long date1, date2;
		date1 = System.currentTimeMillis();
		multiplication_polynome_viaCoeff(tab1, tab2);
		date2 = System.currentTimeMillis();
		System.out.println("   via Coeff: " + (date2 - date1));

		date1 = System.currentTimeMillis();
		multiplication_polynome_viaFFT(tab1, tab2);
		date2 = System.currentTimeMillis();
		System.out.println("   via FFT  : " + (date2 - date1));

		int taille_init = 10;
		int taille_fin = 1000;
		int nbrMesures = 30;
		int taille_incr = (taille_fin-taille_init)/(nbrMesures-1);
		List<Integer> tab_tailles = new ArrayList<>();
		List<Integer> tab_temps = new ArrayList<>();
		for(int n = taille_init; n<=taille_fin; n=n+taille_incr){
			tab1 =random(n);
			tab2 = random(n);
			date1 = System.currentTimeMillis();
			multiplication_polynome_viaCoeff(tab1, tab2);
			date2 = System.currentTimeMillis();
			tab_tailles.add((int) n);
			tab_temps.add((int)(date2-date1));
		}

		Graph g = new Graph(tab_tailles,tab_temps);
		g.display();
		double a = regression(tab_tailles, tab_temps, n -> (double) n*n);
		String tmpCalc = tempsCalculFormat(n -> (double)n*n, 1_000_000, a);
		System.out.println("La multiplication de polynomes pour 1_000_000 d'entrées prendrait %s.".formatted(tmpCalc));
		System.out.println("Le coefficient calculé est a = %e".formatted(a));
		g.addQuadratic(a);
		System.out.println("Appuyer sur entrée pour fermer la fenêtre...");
		scan.nextLine();
		Window fenetre = SwingUtilities.getWindowAncestor(g);
		fenetre.dispose();

		taille_init = 1_000;
		taille_fin = 250_000;
		taille_incr = (taille_fin-taille_init)/(nbrMesures-1);
		tab_tailles = new ArrayList<>();
		tab_temps = new ArrayList<>();
		for(int n = taille_init; n<=taille_fin; n=n+taille_incr){
			tab1 =random(n);
			tab2 = random(n);
			date1 = System.currentTimeMillis();
			multiplication_polynome_viaFFT(tab1, tab2);
			date2 = System.currentTimeMillis();
			tab_tailles.add((int) n);
			tab_temps.add((int)(date2-date1));
		}

		g = new Graph(tab_tailles,tab_temps);
		g.display();
		a = regression(tab_tailles, tab_temps, n -> (double) n * (Math.log(n)));
		tmpCalc = tempsCalculFormat(n -> (double)n * (Math.log(n)), 1_000_000, a);
		System.out.println("La multiplication de polynomes pour 1_000_000 d'entrées prendrait %s.".formatted(tmpCalc));
		System.out.println("Le coefficient calculé est a = %e".formatted(a));
		g.addnLogn(a);
		System.out.println("Appuyer sur entrée pour fermer la fenêtre...");
		scan.nextLine();
		fenetre = SwingUtilities.getWindowAncestor(g);
		fenetre.dispose();

	}

}
