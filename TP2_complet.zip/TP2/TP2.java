import java.io.IOException;

public class TP2{
	public static void main(String[] args){
		// Exercice 1
		int n = 16;
		double[] tab = new double[n];
		double a = 2;
		for(int i = 0; i < n; i++){
			tab[i] = a;
		}
		System.out.println("Vecteur constant :");
		System.out.println(FFT_1D.FFT(tab));
		System.out.println("Sinusoide pure :");
		for(int k = 0; k < n; k++){
			for(int i = 0; i < n; i++){
				tab[i] = Math.cos(2. * Math.PI * k * i / n);
			}
			System.out.println(String.format("k = %d", k));
			System.out.println(FFT_1D.FFT(tab));
		}
		
		for(int i = 0; i < n; i++){
			tab[i] = Math.cos(2. * Math.PI * i / n) + Math.cos(6 * Math.PI / n) / 2.;
		}
		System.out.println("Somme de 2 sinusoides :");
		System.out.println(FFT_1D.FFT(tab));
		for(int i = 0; i < n; i++){
			tab[i] = 4. + 2. * Math.sin(4. * Math.PI * i / n) + Math.cos(14. * Math.PI * i / n);
		}
		System.out.println("La fonction a(t) :");
		System.out.println(FFT_1D.FFT(tab));

		// Exercice 2
		try {
			BytePixmap p = new BytePixmap("tigre_512.pgm");
			CpxImg i = new CpxImg(p);
			FFT_2D.FFT_inverse(FFT_2D.FFT(i)).convert_to_BytePixmap().write("tigre_512_inv.pgm");
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
		}

		// Exercice 3
		String[] imgs = {"mire1", "mire2", "mire3", "fingerprint", "barbara_512"};
		try {
			for(int k = 0; k < imgs.length; k++){
				BytePixmap p = new BytePixmap("%s.pgm".formatted(imgs[k]));
				CpxImg i = new CpxImg(p);
				FFT_2D.FFT(i).convert_to_BytePixmap().write("%s_inv.pgm".formatted(imgs[k]));
			}
		}
		catch (IOException e){
			System.out.println(e.getMessage());
		}

		// Exercice 4
		try{
			BytePixmap p = new BytePixmap("tigre_512.pgm");
			CpxImg i = new CpxImg(p);
			n = i.taille();
			int n_2 = n/2;
			CpxImg i_fft_centre = FFT_2D.FFT(i);
			i_fft_centre.set_p_imag(n_2, n_2, 0);
			i_fft_centre.set_p_reel(n_2, n_2, 0);
			FFT_2D.FFT_inverse(i_fft_centre).convert_to_BytePixmap().write("tigre_512_moins_centre.pgm");
			CpxImg i_fft_centre_1 = FFT_2D.FFT(i);
			i_fft_centre_1.set_p_imag(n_2 + 1, n_2, 0);
			i_fft_centre_1.set_p_reel(n_2 + 1, n_2, 0);
			FFT_2D.FFT_inverse(i_fft_centre_1).convert_to_BytePixmap().write("tigre_512_moins_centre_1.pgm");
			CpxImg i_fft_exterieur = FFT_2D.FFT(i);
			i_fft_exterieur.set_p_imag(0, 0, 0);
			i_fft_exterieur.set_p_reel(0, 0, 0);
			FFT_2D.FFT_inverse(i_fft_exterieur).convert_to_BytePixmap().write("tigre_512_moins_exterieur.pgm");
		}
		catch (IOException e){
			System.out.println(e.getMessage());
		}

		// Exercice 5
		try{
			String filename = "tigre_512";
			BytePixmap p = new BytePixmap(filename + ".pgm");
			for(int k = 128; k >= 0; k-= 24){
				CpxImg i = new CpxImg(p);
				CpxImg i_fft = FFT_2D.FFT(i);
				FFT_2D.compression(i_fft, k);
				FFT_2D.FFT_inverse(i_fft).convert_to_BytePixmap().write(filename + "_compression_%d.pgm".formatted(k));
			}
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}

		// Exercice 6
		try{
			String filename = "tigre_512";
			BytePixmap p = new BytePixmap(filename + ".pgm");
			for(int seuil = 1024; seuil > 1; seuil/= 4){
				CpxImg i = new CpxImg(p);
				CpxImg i_fft = FFT_2D.FFT(i);
				FFT_2D.compression_seuil(i_fft, seuil);
				FFT_2D.FFT_inverse(i_fft).convert_to_BytePixmap().write(filename + "_compression_seuil_%d.pgm".formatted(seuil));
			}
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}

		// Exercice 7
		try{
			String[] filenames = {"tigre_512", "barbara_512"};
			for(String filename : filenames){
				BytePixmap p = new BytePixmap(filename + ".pgm");
				CpxImg i = new CpxImg(p);
				CpxImg i_compression = FFT_2D.FFT(i);
				n = i_compression.taille();
				FFT_2D.compression(i_compression, (int)(n/2 * Math.sqrt(0.1)));
				FFT_2D.FFT_inverse(i_compression).convert_to_BytePixmap().write(filename + "_compression_10per.pgm");
				CpxImg i_compression_seuille = FFT_2D.FFT(i);
				int k = n*n/10;
				int l = n*n;
				int seuil = 10;
				while(l > k){
					l = FFT_2D.compression_seuil(i_compression_seuille, seuil);
					seuil++;
				}
				FFT_2D.FFT_inverse(i_compression_seuille).convert_to_BytePixmap().write(filename + "_compression_seuil_10per.pgm");
			}
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}

	}
}
