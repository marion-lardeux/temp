import java.io.IOException;

public class FFT_2D {

	//renvoie la TFD d'une image de complexes
	public static CpxImg FFT(CpxImg I) {

		CpxImg out = new CpxImg(I.taille());

		// FFT 1D sur les lignes
		for (int k = 0; k < I.taille(); k++)
			out.set_line(k,FFT_1D.FFT(I.get_line(k)));
		  
		// transposition
		out.transpose();

		// FFT 1D sur les "nouvelles" lignes de out (anciennes colonnes)
		for (int k = 0; k < I.taille(); k++)
			out.set_line(k,FFT_1D.FFT(out.get_line(k)));

		//on re transpose pour revenir dans le sens de d�part
		out.transpose();
		
		//on divise par la taille de I
		out.multiply(1./I.taille());
		return out.recentrage();
	}
	
	//renvoie la TFD inverse d'une images de complexes
	public static CpxImg FFT_inverse(CpxImg I) {
		I = I.recentrage();
		CpxImg out = new CpxImg(I.taille());
		for (int k = 0; k < I.taille(); k++)
			out.set_line(k, I.get_line(k).conjugue());

		out = FFT(out).recentrage();
		for (int k = 0; k < I.taille(); k++)
			out.set_line(k, out.get_line(k).conjugue());
		return out;
	}

	// compression par mise  zro des coefficients de frquence 
	// FI contient la TDF de I 
	// Dans FI on met  zros tous les coefficients correspondant  des frquences infrieures  k
	public static void compression(CpxImg FI, int k) {
		int n = FI.taille();
		int n_2 = n/2;
		// on conserve les lignes ET colonnes d'indice dans [n/2-k, n/2+k] (carre centre, symetrique)
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				if(i < n_2 - k || i > n_2 + k || j < n_2 - k || j > n_2 + k){
					FI.set_p_reel(i, j, 0);
					FI.set_p_imag(i, j, 0);
				}
			}
		}
	}

	// compression par seuillage des coefficients faibles
	// FI contient la TDF de I 
	// Dans FI on met  zros tous les coefficients dont le module est infrieur  seuil 
	// on renvoie le nombre de coefficients conservs 
	public static int compression_seuil(CpxImg FI, double seuil){
		int res = 0;
		int n = FI.taille();
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				double a = FI.get_p_reel(i, j);
				double b = FI.get_p_imag(i, j);
				double mod = Math.sqrt(a * a + b * b);
				if(mod < seuil){
					FI.set_p_reel(i, j, 0);
					FI.set_p_imag(i, j, 0);
				} else{
					res++;
				}
			}
		}
		return res;
	}

	
	public static void main(String[] args) {
		
		try {			
			//PLACEZ ICI VOS TESTS en 2D
			//Exemple, lecture
			BytePixmap BP = new BytePixmap("nomfichier.pgm");
			CpxImg I = new CpxImg(BP);
			
			//Exemple, �criture
			BP = I.convert_to_BytePixmap();
			BP.write("nomfichier2.pgm");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
